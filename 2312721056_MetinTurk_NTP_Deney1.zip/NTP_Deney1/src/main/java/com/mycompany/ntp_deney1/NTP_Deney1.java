/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ntp_deney1;

/**
 *
 * @author metin
 */
public class NTP_Deney1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
